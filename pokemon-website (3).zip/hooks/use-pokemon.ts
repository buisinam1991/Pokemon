import useSWR from "swr"
import { API_ENDPOINTS, API_CONFIG } from "@/constants/api"
import type { Pokemon } from "@/types/pokemon"
import { fetchWithRetry, createPlaceholderPokemon, getFallbackPokemonList } from "@/lib/pokemon"

// SWR fetcher function
const fetcher = async (url: string) => {
  try {
    return await fetchWithRetry(url)
  } catch (error) {
    console.error(`SWR fetcher error for ${url}:`, error)
    throw error
  }
}

/**
 * Hook for fetching a paginated list of Pokemon with optional type filtering
 */
export function usePokemonList(page = 1, type = "") {
  const { LIMIT } = API_CONFIG.PAGINATION

  // Create the appropriate key based on whether we're filtering by type
  const getKey = () => {
    if (type) {
      return `pokemon-type-${type}-page-${page}`
    }
    const offset = (page - 1) * LIMIT
    return `${API_ENDPOINTS.POKEMON.LIST}?limit=${LIMIT}&offset=${offset}`
  }

  // Use SWR to fetch the data
  const { data, error, isLoading, isValidating, mutate } = useSWR(
    getKey(),
    async () => {
      try {
        if (type) {
          // If filtering by type, we need to fetch the type data first
          const typeData = await fetcher(API_ENDPOINTS.POKEMON.TYPE(type))
          const pokemonUrls = typeData.pokemon.map((p: any) => p.pokemon.url)
          const count = pokemonUrls.length

          // Calculate pagination
          const offset = (page - 1) * LIMIT
          const paginatedUrls = pokemonUrls.slice(offset, offset + LIMIT)

          // Fetch details for each Pokemon
          const pokemonDetails: Pokemon[] = []

          for (const url of paginatedUrls) {
            try {
              // Use SWR's cache for individual Pokemon if available
              const details = await fetcher(url)
              pokemonDetails.push({
                id: details.id,
                name: details.name,
                image:
                  details.sprites.other["official-artwork"]?.front_default ||
                  details.sprites.front_default ||
                  `/placeholder.svg?height=200&width=200&text=${details.name}`,
                types: details.types.map((t: any) => t.type.name),
                height: details.height,
                weight: details.weight,
                abilities: details.abilities.map((a: any) => a.ability.name),
                stats: details.stats.map((s: any) => ({
                  name: s.stat.name,
                  value: s.base_stat,
                })),
              })
            } catch (error) {
              console.error(`Error fetching details for ${url}:`, error)
              pokemonDetails.push(createPlaceholderPokemon("unknown", url))
            }
          }

          return {
            results: pokemonDetails,
            count,
          }
        } else {
          // Standard pagination without type filtering
          const data = await fetcher(getKey())

          // Fetch details for each Pokemon
          const pokemonDetails: Pokemon[] = []

          for (const pokemon of data.results) {
            try {
              // Use SWR's cache for individual Pokemon if available
              const details = await fetcher(pokemon.url)
              pokemonDetails.push({
                id: details.id,
                name: details.name,
                image:
                  details.sprites.other["official-artwork"]?.front_default ||
                  details.sprites.front_default ||
                  `/placeholder.svg?height=200&width=200&text=${details.name}`,
                types: details.types.map((t: any) => t.type.name),
                height: details.height,
                weight: details.weight,
                abilities: details.abilities.map((a: any) => a.ability.name),
                stats: details.stats.map((s: any) => ({
                  name: s.stat.name,
                  value: s.base_stat,
                })),
              })
            } catch (error) {
              console.error(`Error fetching details for ${pokemon.name}:`, error)
              pokemonDetails.push(createPlaceholderPokemon(pokemon.name, pokemon.url))
            }
          }

          return {
            results: pokemonDetails,
            count: data.count,
          }
        }
      } catch (error) {
        console.error("Error in usePokemonList:", error)
        return getFallbackPokemonList(page)
      }
    },
    {
      revalidateOnFocus: false,
      revalidateIfStale: false,
      dedupingInterval: 60000, // 1 minute
      errorRetryCount: 3,
    },
  )

  return {
    pokemon: data?.results || [],
    count: data?.count || 0,
    isLoading,
    isError: !!error,
    isValidating,
    mutate,
  }
}

/**
 * Hook for fetching a single Pokemon by ID
 */
export function usePokemonDetail(id: string | number) {
  const { data, error, isLoading } = useSWR(
    id ? `pokemon-${id}` : null,
    async () => {
      try {
        const data = await fetcher(API_ENDPOINTS.POKEMON.DETAIL(id))

        return {
          id: data.id,
          name: data.name,
          image:
            data.sprites.other["official-artwork"]?.front_default ||
            data.sprites.front_default ||
            `/placeholder.svg?height=200&width=200&text=${data.name}`,
          types: data.types.map((t: any) => t.type.name),
          height: data.height,
          weight: data.weight,
          abilities: data.abilities.map((a: any) => a.ability.name),
          stats: data.stats.map((s: any) => ({
            name: s.stat.name,
            value: s.base_stat,
          })),
        }
      } catch (error) {
        console.error(`Error fetching Pokemon with ID ${id}:`, error)
        throw error
      }
    },
    {
      revalidateOnFocus: false,
      dedupingInterval: 3600000, // 1 hour
      errorRetryCount: 3,
    },
  )

  return {
    pokemon: data,
    isLoading,
    isError: !!error,
  }
}

/**
 * Hook for fetching all Pokemon types
 */
export function usePokemonTypes() {
  // Cached types as fallback
  const cachedTypes = [
    "normal",
    "fire",
    "water",
    "electric",
    "grass",
    "ice",
    "fighting",
    "poison",
    "ground",
    "flying",
    "psychic",
    "bug",
    "rock",
    "ghost",
    "dragon",
    "dark",
    "steel",
    "fairy",
  ]

  const { data, error, isLoading } = useSWR(
    "pokemon-types",
    async () => {
      try {
        const data = await fetcher(API_ENDPOINTS.POKEMON.TYPES_LIST)

        // Filter out special types like 'unknown' and 'shadow'
        return data.results
          .map((type: { name: string }) => type.name)
          .filter((type: string) => !["unknown", "shadow"].includes(type))
      } catch (error) {
        console.error("Error fetching Pokemon types:", error)
        return cachedTypes
      }
    },
    {
      revalidateOnFocus: false,
      dedupingInterval: 86400000, // 24 hours
      fallbackData: cachedTypes,
    },
  )

  return {
    types: data || cachedTypes,
    isLoading,
    isError: !!error,
  }
}

